import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _6c149bf4 = () => interopDefault(import('..\\pages\\cart\\index.vue' /* webpackChunkName: "pages/cart/index" */))
const _20133dec = () => interopDefault(import('..\\pages\\dashboard\\index.vue' /* webpackChunkName: "pages/dashboard/index" */))
const _15626612 = () => interopDefault(import('..\\pages\\login\\index.vue' /* webpackChunkName: "pages/login/index" */))
const _aa42f8de = () => interopDefault(import('..\\pages\\register\\index.vue' /* webpackChunkName: "pages/register/index" */))
const _33096454 = () => interopDefault(import('..\\pages\\search.vue' /* webpackChunkName: "pages/search" */))
const _4cbe517c = () => interopDefault(import('..\\pages\\test\\index.vue' /* webpackChunkName: "pages/test/index" */))
const _730fa269 = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _8e92e1d8 = () => interopDefault(import('..\\pages\\cart\\checkout.vue' /* webpackChunkName: "pages/cart/checkout" */))
const _5ca57825 = () => interopDefault(import('..\\pages\\cart\\success.vue' /* webpackChunkName: "pages/cart/success" */))
const _0fa9dfec = () => interopDefault(import('..\\pages\\dashboard\\blog\\index.vue' /* webpackChunkName: "pages/dashboard/blog/index" */))
const _f0d1ffa4 = () => interopDefault(import('..\\pages\\dashboard\\category\\index.vue' /* webpackChunkName: "pages/dashboard/category/index" */))
const _24d4d11a = () => interopDefault(import('..\\pages\\dashboard\\order\\index.vue' /* webpackChunkName: "pages/dashboard/order/index" */))
const _4e09d559 = () => interopDefault(import('..\\pages\\dashboard\\product\\index.vue' /* webpackChunkName: "pages/dashboard/product/index" */))
const _4b6460eb = () => interopDefault(import('..\\pages\\dashboard\\slider\\index.vue' /* webpackChunkName: "pages/dashboard/slider/index" */))
const _57ef5f7e = () => interopDefault(import('..\\pages\\dashboard\\user\\index.vue' /* webpackChunkName: "pages/dashboard/user/index" */))
const _e84b3a36 = () => interopDefault(import('..\\pages\\user\\order.vue' /* webpackChunkName: "pages/user/order" */))
const _556ed5b2 = () => interopDefault(import('..\\pages\\user\\setting.vue' /* webpackChunkName: "pages/user/setting" */))
const _d078887c = () => interopDefault(import('..\\pages\\user\\whishlist.vue' /* webpackChunkName: "pages/user/whishlist" */))
const _00946f4e = () => interopDefault(import('..\\pages\\dashboard\\blog\\add.vue' /* webpackChunkName: "pages/dashboard/blog/add" */))
const _14e7717d = () => interopDefault(import('..\\pages\\dashboard\\category\\add.vue' /* webpackChunkName: "pages/dashboard/category/add" */))
const _65d39568 = () => interopDefault(import('..\\pages\\dashboard\\product\\add.vue' /* webpackChunkName: "pages/dashboard/product/add" */))
const _051fdd7a = () => interopDefault(import('..\\pages\\dashboard\\slider\\add.vue' /* webpackChunkName: "pages/dashboard/slider/add" */))
const _c75cd2b0 = () => interopDefault(import('..\\pages\\dashboard\\blog\\edit\\_id.vue' /* webpackChunkName: "pages/dashboard/blog/edit/_id" */))
const _937e5668 = () => interopDefault(import('..\\pages\\dashboard\\category\\edit\\_id.vue' /* webpackChunkName: "pages/dashboard/category/edit/_id" */))
const _a0c1c712 = () => interopDefault(import('..\\pages\\dashboard\\product\\edit\\_id.vue' /* webpackChunkName: "pages/dashboard/product/edit/_id" */))
const _1ec58f09 = () => interopDefault(import('..\\pages\\dashboard\\slider\\edit\\_id.vue' /* webpackChunkName: "pages/dashboard/slider/edit/_id" */))
const _6ad43942 = () => interopDefault(import('..\\pages\\dashboard\\user\\edit\\_id.vue' /* webpackChunkName: "pages/dashboard/user/edit/_id" */))
const _fc8f5bfc = () => interopDefault(import('..\\pages\\dashboard\\order\\_id.vue' /* webpackChunkName: "pages/dashboard/order/_id" */))
const _f0116dcc = () => interopDefault(import('..\\pages\\blog\\_id.vue' /* webpackChunkName: "pages/blog/_id" */))
const _a3c2c384 = () => interopDefault(import('..\\pages\\category\\_id.vue' /* webpackChunkName: "pages/category/_id" */))
const _46724cd9 = () => interopDefault(import('..\\pages\\product\\_id.vue' /* webpackChunkName: "pages/product/_id" */))
const _22ed4e14 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'active',
  scrollBehavior,

  routes: [{
    path: "/cart",
    component: _6c149bf4,
    name: "cart"
  }, {
    path: "/dashboard",
    component: _20133dec,
    name: "dashboard"
  }, {
    path: "/login",
    component: _15626612,
    name: "login"
  }, {
    path: "/register",
    component: _aa42f8de,
    name: "register"
  }, {
    path: "/search",
    component: _33096454,
    name: "search"
  }, {
    path: "/test",
    component: _4cbe517c,
    name: "test"
  }, {
    path: "/user",
    component: _730fa269,
    name: "user"
  }, {
    path: "/cart/checkout",
    component: _8e92e1d8,
    name: "cart-checkout"
  }, {
    path: "/cart/success",
    component: _5ca57825,
    name: "cart-success"
  }, {
    path: "/dashboard/blog",
    component: _0fa9dfec,
    name: "dashboard-blog"
  }, {
    path: "/dashboard/category",
    component: _f0d1ffa4,
    name: "dashboard-category"
  }, {
    path: "/dashboard/order",
    component: _24d4d11a,
    name: "dashboard-order"
  }, {
    path: "/dashboard/product",
    component: _4e09d559,
    name: "dashboard-product"
  }, {
    path: "/dashboard/slider",
    component: _4b6460eb,
    name: "dashboard-slider"
  }, {
    path: "/dashboard/user",
    component: _57ef5f7e,
    name: "dashboard-user"
  }, {
    path: "/user/order",
    component: _e84b3a36,
    name: "user-order"
  }, {
    path: "/user/setting",
    component: _556ed5b2,
    name: "user-setting"
  }, {
    path: "/user/whishlist",
    component: _d078887c,
    name: "user-whishlist"
  }, {
    path: "/dashboard/blog/add",
    component: _00946f4e,
    name: "dashboard-blog-add"
  }, {
    path: "/dashboard/category/add",
    component: _14e7717d,
    name: "dashboard-category-add"
  }, {
    path: "/dashboard/product/add",
    component: _65d39568,
    name: "dashboard-product-add"
  }, {
    path: "/dashboard/slider/add",
    component: _051fdd7a,
    name: "dashboard-slider-add"
  }, {
    path: "/dashboard/blog/edit/:id?",
    component: _c75cd2b0,
    name: "dashboard-blog-edit-id"
  }, {
    path: "/dashboard/category/edit/:id?",
    component: _937e5668,
    name: "dashboard-category-edit-id"
  }, {
    path: "/dashboard/product/edit/:id?",
    component: _a0c1c712,
    name: "dashboard-product-edit-id"
  }, {
    path: "/dashboard/slider/edit/:id?",
    component: _1ec58f09,
    name: "dashboard-slider-edit-id"
  }, {
    path: "/dashboard/user/edit/:id?",
    component: _6ad43942,
    name: "dashboard-user-edit-id"
  }, {
    path: "/dashboard/order/:id",
    component: _fc8f5bfc,
    name: "dashboard-order-id"
  }, {
    path: "/blog/:id?",
    component: _f0116dcc,
    name: "blog-id"
  }, {
    path: "/category/:id?",
    component: _a3c2c384,
    name: "category-id"
  }, {
    path: "/product/:id?",
    component: _46724cd9,
    name: "product-id"
  }, {
    path: "/",
    component: _22ed4e14,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
