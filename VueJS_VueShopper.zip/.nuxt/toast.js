import { createToastInterface } from "vue-toastification";

export default function (ctx, inject) {
  const toast = createToastInterface({"cssFile":"C:\\xampp2\\htdocs\\VueJS\\VueShopper\\node_modules\\vue-toastification\\dist\\index.css"});
  inject('toast', toast);
}
