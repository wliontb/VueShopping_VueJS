import Vue from 'vue'
import { wrapFunctional } from './utils'

const components = {
  LoadingBar: () => import('../..\\components\\LoadingBar.vue' /* webpackChunkName: "components/loading-bar" */).then(c => wrapFunctional(c.default || c)),
  Logo: () => import('../..\\components\\Logo.vue' /* webpackChunkName: "components/logo" */).then(c => wrapFunctional(c.default || c)),
  BlogListBlogHome: () => import('../..\\components\\Blog\\ListBlogHome.vue' /* webpackChunkName: "components/blog-list-blog-home" */).then(c => wrapFunctional(c.default || c)),
  CartMiniCart: () => import('../..\\components\\Cart\\MiniCart.vue' /* webpackChunkName: "components/cart-mini-cart" */).then(c => wrapFunctional(c.default || c)),
  BootstrapComponentToast: () => import('../..\\components\\BootstrapComponent\\Toast.vue' /* webpackChunkName: "components/bootstrap-component-toast" */).then(c => wrapFunctional(c.default || c)),
  ChartBarChart: () => import('../..\\components\\Chart\\BarChart.js' /* webpackChunkName: "components/chart-bar-chart" */).then(c => wrapFunctional(c.default || c)),
  ChartLineChart: () => import('../..\\components\\Chart\\LineChart.js' /* webpackChunkName: "components/chart-line-chart" */).then(c => wrapFunctional(c.default || c)),
  ChartPieChart: () => import('../..\\components\\Chart\\PieChart.js' /* webpackChunkName: "components/chart-pie-chart" */).then(c => wrapFunctional(c.default || c)),
  CategoryListProduct: () => import('../..\\components\\Category\\ListProduct.vue' /* webpackChunkName: "components/category-list-product" */).then(c => wrapFunctional(c.default || c)),
  FooterDefaultFooter: () => import('../..\\components\\Footer\\DefaultFooter.vue' /* webpackChunkName: "components/footer-default-footer" */).then(c => wrapFunctional(c.default || c)),
  FormSubscribeForm: () => import('../..\\components\\Form\\SubscribeForm.vue' /* webpackChunkName: "components/form-subscribe-form" */).then(c => wrapFunctional(c.default || c)),
  DashboardBarChart: () => import('../..\\components\\Dashboard\\BarChart.vue' /* webpackChunkName: "components/dashboard-bar-chart" */).then(c => wrapFunctional(c.default || c)),
  DashboardLineChart: () => import('../..\\components\\Dashboard\\LineChart.vue' /* webpackChunkName: "components/dashboard-line-chart" */).then(c => wrapFunctional(c.default || c)),
  DashboardListBlog: () => import('../..\\components\\Dashboard\\ListBlog.vue' /* webpackChunkName: "components/dashboard-list-blog" */).then(c => wrapFunctional(c.default || c)),
  DashboardListCategory: () => import('../..\\components\\Dashboard\\ListCategory.vue' /* webpackChunkName: "components/dashboard-list-category" */).then(c => wrapFunctional(c.default || c)),
  DashboardListOrder: () => import('../..\\components\\Dashboard\\ListOrder.vue' /* webpackChunkName: "components/dashboard-list-order" */).then(c => wrapFunctional(c.default || c)),
  DashboardListProduct: () => import('../..\\components\\Dashboard\\ListProduct.vue' /* webpackChunkName: "components/dashboard-list-product" */).then(c => wrapFunctional(c.default || c)),
  DashboardListSlider: () => import('../..\\components\\Dashboard\\ListSlider.vue' /* webpackChunkName: "components/dashboard-list-slider" */).then(c => wrapFunctional(c.default || c)),
  DashboardListUser: () => import('../..\\components\\Dashboard\\ListUser.vue' /* webpackChunkName: "components/dashboard-list-user" */).then(c => wrapFunctional(c.default || c)),
  DashboardPieChart: () => import('../..\\components\\Dashboard\\PieChart.vue' /* webpackChunkName: "components/dashboard-pie-chart" */).then(c => wrapFunctional(c.default || c)),
  DashboardSidebarDashboard: () => import('../..\\components\\Dashboard\\SidebarDashboard.vue' /* webpackChunkName: "components/dashboard-sidebar-dashboard" */).then(c => wrapFunctional(c.default || c)),
  DashboardStat: () => import('../..\\components\\Dashboard\\Stat.vue' /* webpackChunkName: "components/dashboard-stat" */).then(c => wrapFunctional(c.default || c)),
  LogoListLogo: () => import('../..\\components\\Logo\\ListLogo.vue' /* webpackChunkName: "components/logo-list-logo" */).then(c => wrapFunctional(c.default || c)),
  HeaderDefaultHeader: () => import('../..\\components\\Header\\DefaultHeader.vue' /* webpackChunkName: "components/header-default-header" */).then(c => wrapFunctional(c.default || c)),
  HeaderMobileHeader: () => import('../..\\components\\Header\\MobileHeader.vue' /* webpackChunkName: "components/header-mobile-header" */).then(c => wrapFunctional(c.default || c)),
  MenuCategoryMenu: () => import('../..\\components\\Menu\\CategoryMenu.vue' /* webpackChunkName: "components/menu-category-menu" */).then(c => wrapFunctional(c.default || c)),
  MenuHomeMenu: () => import('../..\\components\\Menu\\HomeMenu.vue' /* webpackChunkName: "components/menu-home-menu" */).then(c => wrapFunctional(c.default || c)),
  MenuPopularMenu: () => import('../..\\components\\Menu\\PopularMenu.vue' /* webpackChunkName: "components/menu-popular-menu" */).then(c => wrapFunctional(c.default || c)),
  MenuTopMenu: () => import('../..\\components\\Menu\\TopMenu.vue' /* webpackChunkName: "components/menu-top-menu" */).then(c => wrapFunctional(c.default || c)),
  ProductListDeal: () => import('../..\\components\\Product\\ListDeal.vue' /* webpackChunkName: "components/product-list-deal" */).then(c => wrapFunctional(c.default || c)),
  ProductListRecommend: () => import('../..\\components\\Product\\ListRecommend.vue' /* webpackChunkName: "components/product-list-recommend" */).then(c => wrapFunctional(c.default || c)),
  ServiceArea: () => import('../..\\components\\Service\\ServiceArea.vue' /* webpackChunkName: "components/service-area" */).then(c => wrapFunctional(c.default || c)),
  SliderDefaultSlider: () => import('../..\\components\\Slider\\DefaultSlider.vue' /* webpackChunkName: "components/slider-default-slider" */).then(c => wrapFunctional(c.default || c)),
  UserDetailOrder: () => import('../..\\components\\User\\DetailOrder.vue' /* webpackChunkName: "components/user-detail-order" */).then(c => wrapFunctional(c.default || c)),
  UserListOrder: () => import('../..\\components\\User\\ListOrder.vue' /* webpackChunkName: "components/user-list-order" */).then(c => wrapFunctional(c.default || c)),
  UserAside: () => import('../..\\components\\User\\UserAside.vue' /* webpackChunkName: "components/user-aside" */).then(c => wrapFunctional(c.default || c)),
  UserMenu: () => import('../..\\components\\User\\UserMenu.vue' /* webpackChunkName: "components/user-menu" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
