import { wrapFunctional } from './utils'

export { default as LoadingBar } from '../..\\components\\LoadingBar.vue'
export { default as Logo } from '../..\\components\\Logo.vue'
export { default as BlogListBlogHome } from '../..\\components\\Blog\\ListBlogHome.vue'
export { default as CartMiniCart } from '../..\\components\\Cart\\MiniCart.vue'
export { default as BootstrapComponentToast } from '../..\\components\\BootstrapComponent\\Toast.vue'
export { default as ChartBarChart } from '../..\\components\\Chart\\BarChart.js'
export { default as ChartLineChart } from '../..\\components\\Chart\\LineChart.js'
export { default as ChartPieChart } from '../..\\components\\Chart\\PieChart.js'
export { default as CategoryListProduct } from '../..\\components\\Category\\ListProduct.vue'
export { default as FooterDefaultFooter } from '../..\\components\\Footer\\DefaultFooter.vue'
export { default as FormSubscribeForm } from '../..\\components\\Form\\SubscribeForm.vue'
export { default as DashboardBarChart } from '../..\\components\\Dashboard\\BarChart.vue'
export { default as DashboardLineChart } from '../..\\components\\Dashboard\\LineChart.vue'
export { default as DashboardListBlog } from '../..\\components\\Dashboard\\ListBlog.vue'
export { default as DashboardListCategory } from '../..\\components\\Dashboard\\ListCategory.vue'
export { default as DashboardListOrder } from '../..\\components\\Dashboard\\ListOrder.vue'
export { default as DashboardListProduct } from '../..\\components\\Dashboard\\ListProduct.vue'
export { default as DashboardListSlider } from '../..\\components\\Dashboard\\ListSlider.vue'
export { default as DashboardListUser } from '../..\\components\\Dashboard\\ListUser.vue'
export { default as DashboardPieChart } from '../..\\components\\Dashboard\\PieChart.vue'
export { default as DashboardSidebarDashboard } from '../..\\components\\Dashboard\\SidebarDashboard.vue'
export { default as DashboardStat } from '../..\\components\\Dashboard\\Stat.vue'
export { default as LogoListLogo } from '../..\\components\\Logo\\ListLogo.vue'
export { default as HeaderDefaultHeader } from '../..\\components\\Header\\DefaultHeader.vue'
export { default as HeaderMobileHeader } from '../..\\components\\Header\\MobileHeader.vue'
export { default as MenuCategoryMenu } from '../..\\components\\Menu\\CategoryMenu.vue'
export { default as MenuHomeMenu } from '../..\\components\\Menu\\HomeMenu.vue'
export { default as MenuPopularMenu } from '../..\\components\\Menu\\PopularMenu.vue'
export { default as MenuTopMenu } from '../..\\components\\Menu\\TopMenu.vue'
export { default as ProductListDeal } from '../..\\components\\Product\\ListDeal.vue'
export { default as ProductListRecommend } from '../..\\components\\Product\\ListRecommend.vue'
export { default as ServiceArea } from '../..\\components\\Service\\ServiceArea.vue'
export { default as SliderDefaultSlider } from '../..\\components\\Slider\\DefaultSlider.vue'
export { default as UserDetailOrder } from '../..\\components\\User\\DetailOrder.vue'
export { default as UserListOrder } from '../..\\components\\User\\ListOrder.vue'
export { default as UserAside } from '../..\\components\\User\\UserAside.vue'
export { default as UserMenu } from '../..\\components\\User\\UserMenu.vue'

export const LazyLoadingBar = import('../..\\components\\LoadingBar.vue' /* webpackChunkName: "components/loading-bar" */).then(c => wrapFunctional(c.default || c))
export const LazyLogo = import('../..\\components\\Logo.vue' /* webpackChunkName: "components/logo" */).then(c => wrapFunctional(c.default || c))
export const LazyBlogListBlogHome = import('../..\\components\\Blog\\ListBlogHome.vue' /* webpackChunkName: "components/blog-list-blog-home" */).then(c => wrapFunctional(c.default || c))
export const LazyCartMiniCart = import('../..\\components\\Cart\\MiniCart.vue' /* webpackChunkName: "components/cart-mini-cart" */).then(c => wrapFunctional(c.default || c))
export const LazyBootstrapComponentToast = import('../..\\components\\BootstrapComponent\\Toast.vue' /* webpackChunkName: "components/bootstrap-component-toast" */).then(c => wrapFunctional(c.default || c))
export const LazyChartBarChart = import('../..\\components\\Chart\\BarChart.js' /* webpackChunkName: "components/chart-bar-chart" */).then(c => wrapFunctional(c.default || c))
export const LazyChartLineChart = import('../..\\components\\Chart\\LineChart.js' /* webpackChunkName: "components/chart-line-chart" */).then(c => wrapFunctional(c.default || c))
export const LazyChartPieChart = import('../..\\components\\Chart\\PieChart.js' /* webpackChunkName: "components/chart-pie-chart" */).then(c => wrapFunctional(c.default || c))
export const LazyCategoryListProduct = import('../..\\components\\Category\\ListProduct.vue' /* webpackChunkName: "components/category-list-product" */).then(c => wrapFunctional(c.default || c))
export const LazyFooterDefaultFooter = import('../..\\components\\Footer\\DefaultFooter.vue' /* webpackChunkName: "components/footer-default-footer" */).then(c => wrapFunctional(c.default || c))
export const LazyFormSubscribeForm = import('../..\\components\\Form\\SubscribeForm.vue' /* webpackChunkName: "components/form-subscribe-form" */).then(c => wrapFunctional(c.default || c))
export const LazyDashboardBarChart = import('../..\\components\\Dashboard\\BarChart.vue' /* webpackChunkName: "components/dashboard-bar-chart" */).then(c => wrapFunctional(c.default || c))
export const LazyDashboardLineChart = import('../..\\components\\Dashboard\\LineChart.vue' /* webpackChunkName: "components/dashboard-line-chart" */).then(c => wrapFunctional(c.default || c))
export const LazyDashboardListBlog = import('../..\\components\\Dashboard\\ListBlog.vue' /* webpackChunkName: "components/dashboard-list-blog" */).then(c => wrapFunctional(c.default || c))
export const LazyDashboardListCategory = import('../..\\components\\Dashboard\\ListCategory.vue' /* webpackChunkName: "components/dashboard-list-category" */).then(c => wrapFunctional(c.default || c))
export const LazyDashboardListOrder = import('../..\\components\\Dashboard\\ListOrder.vue' /* webpackChunkName: "components/dashboard-list-order" */).then(c => wrapFunctional(c.default || c))
export const LazyDashboardListProduct = import('../..\\components\\Dashboard\\ListProduct.vue' /* webpackChunkName: "components/dashboard-list-product" */).then(c => wrapFunctional(c.default || c))
export const LazyDashboardListSlider = import('../..\\components\\Dashboard\\ListSlider.vue' /* webpackChunkName: "components/dashboard-list-slider" */).then(c => wrapFunctional(c.default || c))
export const LazyDashboardListUser = import('../..\\components\\Dashboard\\ListUser.vue' /* webpackChunkName: "components/dashboard-list-user" */).then(c => wrapFunctional(c.default || c))
export const LazyDashboardPieChart = import('../..\\components\\Dashboard\\PieChart.vue' /* webpackChunkName: "components/dashboard-pie-chart" */).then(c => wrapFunctional(c.default || c))
export const LazyDashboardSidebarDashboard = import('../..\\components\\Dashboard\\SidebarDashboard.vue' /* webpackChunkName: "components/dashboard-sidebar-dashboard" */).then(c => wrapFunctional(c.default || c))
export const LazyDashboardStat = import('../..\\components\\Dashboard\\Stat.vue' /* webpackChunkName: "components/dashboard-stat" */).then(c => wrapFunctional(c.default || c))
export const LazyLogoListLogo = import('../..\\components\\Logo\\ListLogo.vue' /* webpackChunkName: "components/logo-list-logo" */).then(c => wrapFunctional(c.default || c))
export const LazyHeaderDefaultHeader = import('../..\\components\\Header\\DefaultHeader.vue' /* webpackChunkName: "components/header-default-header" */).then(c => wrapFunctional(c.default || c))
export const LazyHeaderMobileHeader = import('../..\\components\\Header\\MobileHeader.vue' /* webpackChunkName: "components/header-mobile-header" */).then(c => wrapFunctional(c.default || c))
export const LazyMenuCategoryMenu = import('../..\\components\\Menu\\CategoryMenu.vue' /* webpackChunkName: "components/menu-category-menu" */).then(c => wrapFunctional(c.default || c))
export const LazyMenuHomeMenu = import('../..\\components\\Menu\\HomeMenu.vue' /* webpackChunkName: "components/menu-home-menu" */).then(c => wrapFunctional(c.default || c))
export const LazyMenuPopularMenu = import('../..\\components\\Menu\\PopularMenu.vue' /* webpackChunkName: "components/menu-popular-menu" */).then(c => wrapFunctional(c.default || c))
export const LazyMenuTopMenu = import('../..\\components\\Menu\\TopMenu.vue' /* webpackChunkName: "components/menu-top-menu" */).then(c => wrapFunctional(c.default || c))
export const LazyProductListDeal = import('../..\\components\\Product\\ListDeal.vue' /* webpackChunkName: "components/product-list-deal" */).then(c => wrapFunctional(c.default || c))
export const LazyProductListRecommend = import('../..\\components\\Product\\ListRecommend.vue' /* webpackChunkName: "components/product-list-recommend" */).then(c => wrapFunctional(c.default || c))
export const LazyServiceArea = import('../..\\components\\Service\\ServiceArea.vue' /* webpackChunkName: "components/service-area" */).then(c => wrapFunctional(c.default || c))
export const LazySliderDefaultSlider = import('../..\\components\\Slider\\DefaultSlider.vue' /* webpackChunkName: "components/slider-default-slider" */).then(c => wrapFunctional(c.default || c))
export const LazyUserDetailOrder = import('../..\\components\\User\\DetailOrder.vue' /* webpackChunkName: "components/user-detail-order" */).then(c => wrapFunctional(c.default || c))
export const LazyUserListOrder = import('../..\\components\\User\\ListOrder.vue' /* webpackChunkName: "components/user-list-order" */).then(c => wrapFunctional(c.default || c))
export const LazyUserAside = import('../..\\components\\User\\UserAside.vue' /* webpackChunkName: "components/user-aside" */).then(c => wrapFunctional(c.default || c))
export const LazyUserMenu = import('../..\\components\\User\\UserMenu.vue' /* webpackChunkName: "components/user-menu" */).then(c => wrapFunctional(c.default || c))
