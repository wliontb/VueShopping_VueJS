<template>
  <div class="subscribe-area bg-gray-4 pt-95 pb-95">
    <div class="container">
      <div class="row">
        <div class="col-lg-5 col-md-5">
          <div class="section-title-3">
            <h2>Our Newsletter</h2>
            <p>Get updates by subscribe our weekly newsletter</p>
          </div>
        </div>
        <div class="col-lg-7 col-md-7">
          <div id="mc_embed_signup" class="subscribe-form-2">
            <form
              id="mc-embedded-subscribe-form"
              class="validate subscribe-form-style-2"
              novalidate=""
              target="_blank"
              name="mc-embedded-subscribe-form"
              method="post"
              action="http://devitems.us11.list-manage.com/subscribe/post?u=6bbb9b6f5827bd842d9640c82&amp;id=05d85f18ef"
            >
              <div id="mc_embed_signup_scroll" class="mc-form-2">
                <input
                  class="email"
                  type="email"
                  required=""
                  placeholder="Enter your email address"
                  name="EMAIL"
                  value=""
                />
                <div class="mc-news-2" aria-hidden="true">
                  <input
                    type="text"
                    value=""
                    tabindex="-1"
                    name="b_6bbb9b6f5827bd842d9640c82_05d85f18ef"
                  />
                </div>
                <div class="clear-2">
                  <input
                    id="mc-embedded-subscribe"
                    class="button"
                    type="submit"
                    name="subscribe"
                    value="Subscribe"
                  />
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
