<template>
  <div>
    <section class="padding-bottom">
      <header class="section-heading heading-line">
        <h4 class="title-section text-uppercase">Đối Tác</h4>
      </header>

      <ul class="row mt-4">
        <li class="col-md col-6">
          <a href="#" class="icontext">
            <img class="icon-flag" src="images/brand/brand1.jpg" />
          </a>
        </li>
        <li class="col-md col-6">
          <a href="#" class="icontext">
            <img class="icon-flag" src="images/brand/brand2.jpg" />
          </a>
        </li>
        <li class="col-md col-6">
          <a href="#" class="icontext">
            <img class="icon-flag" src="images/brand/brand3.jpg" />
          </a>
        </li>
        <li class="col-md col-6">
          <a href="#" class="icontext">
            <img class="icon-flag" src="images/brand/brand4.jpg" />
          </a>
        </li>
        <li class="col-md col-6">
          <a href="#" class="icontext">
            <img class="icon-flag" src="images/brand/brand5.jpg" />
          </a>
        </li>
        <li class="col-md col-6">
          <a href="#" class="icontext">
            <img class="icon-flag" src="images/brand/brand7.jpg" />
          </a>
        </li>
        <li class="col-md col-6">
          <a href="#" class="icontext">
            <img class="icon-flag" src="images/brand/brand8.jpg" />
          </a>
        </li>
        <li class="col-md col-6">
          <a href="#" class="icontext">
            <img class="icon-flag" src="images/brand/brand9.jpg" />
          </a>
        </li>
      </ul>
    </section>
  </div>
</template>
<style lang="css">
.icon-flag {
  max-width: 100%;
  border-radius: 20%;
}
</style>
