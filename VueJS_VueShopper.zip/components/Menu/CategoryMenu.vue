<template>
  <aside class="col-lg col-md-3 flex-lg-grow-0">
    <nav class="nav-home-aside">
      <h6 class="title-category">
        DANH MỤC <i class="d-md-none icon fa fa-chevron-down"></i>
      </h6>
      <ul class="menu-category">
        <li v-for="category in categories" :key="category.id">
          <a href="#">{{ category.name }}</a>
        </li>
        <li class="has-submenu">
          <a href="#">More items</a>
          <ul class="submenu">
            <li><a href="#">Submenu name</a></li>
            <li><a href="#">Great submenu</a></li>
            <li><a href="#">Another menu</a></li>
            <li><a href="#">Some others</a></li>
          </ul>
        </li>
      </ul>
    </nav>
  </aside>
</template>
<script>
export default {
  data() {
    return {
      categories: this.$store.getters.categories,
    }
  },
}
</script>
