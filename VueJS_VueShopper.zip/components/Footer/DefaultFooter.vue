<template>
  <!-- ========================= FOOTER ========================= -->
  <footer class="section-footer bg-secondary text-white">
    <div class="container">
      <section class="footer-top padding-y-lg">
        <div class="row">
          <aside class="col-md-4 col-12">
            <article class="mr-md-4">
              <p>
                <img
                  src="~/assets/images/logo.png"
                  class="logo_footer"
                  alt=""
                />
              </p>
              <p>Lầu 5, 387-389 Hai Bà Trưng Quận 3 TP HCM</p>
              <ul class="list-icon">
                <li>
                  <i class="icon fa fa-map-marker"> </i>Công Ty Cổ Phần Phát
                  Hành Sách TP HCM - FAHASA 60 - 62 Lê Lợi, Quận 1, TP. HCM,
                  Việt Nam
                </li>
                <li><i class="icon fa fa-envelope"> </i> info@fahasa.com</li>
                <li><i class="icon fa fa-phone"> </i> 1900636467</li>
              </ul>
            </article>
          </aside>
          <aside class="col-md col-6">
            <h5 class="title text-uppercase title-foot">Dịch vụ</h5>
            <ul class="list-unstyled">
              <li><a href="#">Điều khoản sử dụng</a></li>
              <li><a href="#">Chính sách bảo mật</a></li>
              <li><a href="#">Chính sách đổi trả</a></li>
              <li><a href="#">Giới thiệu Fahasa</a></li>
              <li><a href="#">Hệ thống trung tâm - nhà sách</a></li>
            </ul>
          </aside>
          <aside class="col-md col-6">
            <h5 class="title text-uppercase title-foot">Tài khoản của tôi</h5>
            <ul class="list-unstyled">
              <li><a href="#">Đăng nhập</a></li>
              <li><a href="#">Đăng ký tài khoản</a></li>
              <li><a href="#">Chi tiết tài khoản</a></li>
              <li><a href="#">Lịch sử mua hàng</a></li>
            </ul>
          </aside>
          <aside class="col-md-4 col-12">
            <h5 class="title text-uppercase title-foot">Đăng ký nhận tin</h5>

            <form class="form-inline mb-3">
              <input
                type="text"
                placeholder="Email"
                class="border-0 w-auto form-control"
                name=""
              />
              <button class="btn ml-2 btn-warning">Đăng ký</button>
            </form>

            <p class="text-white-50 mb-2">Theo dõi trên mạng xã hội</p>
            <div>
              <a href="#" class="btn btn-icon btn-outline-light"
                ><i class="fab fa-facebook-f"></i
              ></a>
              <a href="#" class="btn btn-icon btn-outline-light"
                ><i class="fab fa-twitter"></i
              ></a>
              <a href="#" class="btn btn-icon btn-outline-light"
                ><i class="fab fa-instagram"></i
              ></a>
              <a href="#" class="btn btn-icon btn-outline-light"
                ><i class="fab fa-youtube"></i
              ></a>
            </div>
          </aside>
        </div>
        <!-- row.// -->
      </section>
      <!-- footer-top.// -->
    </div>
    <!-- //container -->
  </footer>
  <!-- ========================= FOOTER END // ========================= -->
</template>
<style lang="css">
.title-foot {
  color: #ff6a00;
}
.logo_footer {
  max-width: 200px;
}
</style>
